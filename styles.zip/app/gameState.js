function initState() {
    const state = {
        player: 'Player 1'
    }

    return state;
}