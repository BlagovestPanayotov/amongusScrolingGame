function initGameObjects(){
    const gameScreen = document.querySelector('.game-screen');
    const btn = document.querySelector('.start-button');

    return {
        gameScreen,
        btn,
        // hero,
    }
}